Mac:
1. Navigate to ~/Library/Application Support/Adobe/CEP/extensions

Windows:
1. Navigate to C:\Program Files\Adobe\Adobe Photoshop CC 2015\Required\CEP\extensions

Both:
2. Copy the me.randomuser.RandomUserGenerator folder to the extensions folder
3. Restart Photoshop
